// App.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { API_URL } from './config';

export default function App() {
  const [tickets, setTickets] = useState([]);
  const [error, setError] = useState(null);

  const fetchTickets = async () => {
    try {
      const response = await axios.get(`${API_URL}/tickets`);
      setTickets(response.data);
    } catch (err) {
      console.error('Error loading tickets:', err);
      setError('Failed to load tickets.');
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  return (
    <div>
      <h1>Support Tickets</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <ul>
        {tickets.map(ticket => (
          <li key={ticket._id}>{ticket.title}</li>
        ))}
      </ul>
    </div>
  );
}
