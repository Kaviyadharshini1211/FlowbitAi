import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import TicketAppLoader from './pages/TicketAppLoader';
import Login from './pages/Login';
import Tickets from './pages/Tickets';

import { isLoggedIn } from "./utils/auth"; // ✅ Make sure this exports a function

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/tickets" element={<TicketAppLoader />} />
        <Route path="/login" element={<Login onLogin={() => window.location.href = '/'} />} />
        <Route path="/" element={isLoggedIn() ? <Tickets /> : <Navigate to="/login" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
