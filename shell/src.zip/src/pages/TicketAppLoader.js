import React, { Suspense, lazy } from 'react';

const RemoteTicketApp = lazy(() => import('support_tickets/App'));

export default function TicketAppLoader() {
  return (
    <Suspense fallback={<div>Loading Ticket App...</div>}>
      <RemoteTicketApp />
    </Suspense>
  );
}
