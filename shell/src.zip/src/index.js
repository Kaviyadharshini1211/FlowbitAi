
import('./bootstrap'); // <-- defer loading

